package com.vogella.maven.Ecafe;

/**
 * Hello world!
 *
 */


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.Scanner;



public class App {
	public static Connection connection=null;
	public static PreparedStatement prep_statement = null;
	public void Displaymenu() throws SQLException
	{
		    Statement statement = connection.createStatement();
	        ResultSet rs = statement.executeQuery("SELECT * FROM foodmenu");

	        System.out.print("what is this\n");
	        		
	        		while (rs.next()){
	        			System.out.print(rs.getInt(1));
	        			System.out.print("\t");
	        			System.out.print(rs.getString(2));
	        			System.out.print("\t");
	        			System.out.print(rs.getString(3));
	        			System.out.print("\n");
	        			}
	}
	
	
	
	
	
	public void SelectOrder() throws SQLException
	{
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter order by entering item no:");
		int hours=LocalDateTime.now().getHour();
		int min=LocalDateTime.now().getMinute();
		 System.out.print(hours);
		 System.out.print(min);
		 int choice=0;
		 String list="";
		 int price=0;
		 String comment="";
		 
		 
		 
		 Statement statement=connection.createStatement();
		 
		 
		 while(true)
		 {
			 System.out.println("Enter order choice:\nEnter (0) to Exit:\n");
			 
			 choice=scanner.nextInt();
			 
			 if(choice==0)
				 break;
			 else if( (hours>12 && hours>=23) || (hours<12 && hours<=11) )
			 {
				 list="Null";
				 price=0;
				 comment= "Order not successfull  + cafe is closed and Time="+hours+":"+min;
			 }
			 else
			 {
				 String sql = "SELECT * FROM foodmenu";
				 prep_statement=connection.prepareStatement(sql);
				 
				 ResultSet rs = prep_statement.executeQuery(sql);
	        		while (rs.next()){
	        			
	        		if(rs.getInt(1)==choice)
	        		{
	        			list+=rs.getString(2)+"+ ";
	        			price=price+rs.getInt(3);
	        		}
	        			
	        		}
	        		comment="Order Successful at Time="+hours+":"+min;
			 }
			 
		 }
		 
		 System.out.println("Order list is:");
		 System.out.println(list);
		 System.out.println("\n");
		 System.out.println("Order Price is:");
		 System.out.println(price);
		 
		 String SQL = " Insert into order_table (Order_list,Order_price,Comments) values (?,?,?)";
		 prep_statement = connection.prepareStatement(SQL);
		 prep_statement.setString(1,list); // This would set age
		 prep_statement.setInt(2, price); // This would set FN
		 prep_statement.setString(3, comment);
		 int rows=prep_statement.executeUpdate();
		//int rows=statement.executeUpdate(query);
		System.out.println("Number of rows are: ");
		System.out.print(rows);
		scanner.close();
		//('"+list+"',"+price+",'"+comment+"')
	}
	
	
	
	 
	public static void main(String[] args) throws SQLException {
		 
		 String pass="";
		 String name="root";
	        System.out.println("Hello World!"); //Display the string.
	        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/e_cafe",name,pass);
	        //Statement statement = connection.createStatement();
	       
	        //this code is for callable statement
	        
	        CallableStatement cstmt = connection.prepareCall("{call display(?, ?,?)}");
	        cstmt.setInt(1,7);
	        cstmt.registerOutParameter(1, java.sql.Types.INTEGER);
	        cstmt.registerOutParameter(2, java.sql.Types.VARCHAR);
	        cstmt.registerOutParameter(3,java.sql.Types.INTEGER);
	        
	       
	        cstmt.execute();
	        int IO_id=cstmt.getInt(1);
	        String OUT_name = cstmt.getString(2);
	        int OUT_price = cstmt.getInt(3);
	        System.out.println("This is information for a particular food\n\n");
	        System.out.println("ID\tFoodName\tPrice\n");
		    System.out.print(IO_id);
		    System.out.println("\t");
		    System.out.println(OUT_name);
		    System.out.println("\t");
		    System.out.print(OUT_price);
	        
	      //this code is for e_cafe functionality  
	        
		 //Prac obj = new Prac();
		 //obj.Displaymenu();
		 //obj.SelectOrder();
	}

}
